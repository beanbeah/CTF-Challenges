import 'dart:io';
import 'dart:convert';

//flag has the format "WH2023{...}"
final List<int> flag = [];
void main() {
  print("Please enter the flag: ");
  List<int> input = stdin.readLineSync(encoding: latin1)!.codeUnits;
  if (input.length != flag.length) {
    print("Wrong length!");
    return;
  }
  List<int> output = [];
  for (int i = 0; i < input.length; i++) {
    output.add(input[i] ^ input[(i + 1) % input.length]);
  }
  for (int i = 0; i < output.length; i++) {
    output[i] = output[i] ^ i;
  }
  for (int i = 0; i < flag.length; i++) {
    if (output[i] != flag[i]) {
      print("Wrong flag!");
      return;
    }
  }
  print("Correct flag!");
}
